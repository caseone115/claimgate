# Evidence

Drop in whatever you can actually point at: the product spec, the case study,
the signed-off figure, the security certificate, the paper. `.md`, `.txt` and
`.html` files in this folder are all read.

The one rule that matters

Every figure in a claim must appear in an evidence file. That check is a string
comparison, not a judgement call, so a number that was invented — by a model or
by a person at 5pm — cannot be talked into a pass. Write the numbers down
exactly as they appear in your source.

You can also point at a JSON array instead of a folder:

    [{"id": "spec", "title": "Product spec", "text": "Throughput is 1,400 rows
      per minute..."},
     {"id": "case-1", "title": "Meridian case study", "url": "https://..."}]
