# Evidence pack for the demo draft.
# In production this is the customer's own substantiation library: the product
# spec sheet, the case study, the signed contract, the research paper.

## Product specification — Acme Invoicing

Acme Invoicing reconciles invoices against bank statements. On the internal
benchmark of 1,200 invoices it reconciled 87 per cent of line items without
manual intervention. The remaining 13 per cent require review by a finance
team member.

Setup takes an average of 45 minutes for a new account, including connecting
the accounting system and importing the chart of accounts.

The product runs in the customer's own cloud tenancy. Customer data is
encrypted at rest with AES-256 and in transit with TLS 1.3. The service holds
SOC 2 Type II certification, report dated 14 March 2026.

Acme Invoicing is available in Australia, New Zealand, the United Kingdom and
the European Union. Pricing starts at 299 Australian dollars per month for up
to 5,000 invoices.

## Customer case study — Meridian Freight

Meridian Freight, a freight forwarder with 62 staff, adopted Acme Invoicing in
February 2026. Their finance team of 4 people previously spent 22 hours a week
on invoice reconciliation. After the change, the same team reported spending
9 hours a week on the task.

Meridian's finance manager, Dana Whitfield, said: "We did not reduce headcount.
We stopped working weekends at month end."

Acme Invoicing does not guarantee any specific reduction in headcount, cost or
processing time. Results depend on the customer's own invoice volume, data
quality and process.

## Security overview

No security incidents involving customer data have been recorded since the
service launched. The service is penetration-tested annually by an external
firm; the most recent test completed in July 2026.

Acme Invoicing is not certified under ISO 27001 and makes no claim to be.
