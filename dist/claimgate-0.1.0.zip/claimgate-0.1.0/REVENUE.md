# Revenue

The only file that decides whether this is working. Kept deliberately blunt:
no projections, no "pipeline", no dressed-up zero.

**TOTAL: $0.00**

(Two real recipients have now been written to. No reply and no sale: an
outreach message is not revenue and is not counted as any.)

---

## Where the machine is

Built, listed, live, and payable. Nothing is blocked; what is missing is a
customer, which is the only thing that was ever going to be hard.

| Step | State |
|---|---|
| Product built and tested | ✅ 55/55 engine + 21/21 outreach checks pass (was 45/45 before the 2026-09-30 medical-rule fix) |
| Free starter kit built and tested | ✅ 36/36 — `claimgate init` (was 34; the two added checks fail if the kit stops carrying the launch link) |
| **Gumroad Discover reachable at all** | ❌ **NOT until the first sale.** Checked 2026-09-30 in Gumroad's own help centre: Discover eligibility is account-level and requires a **$100 balance from real sales** *and* a risk-review pass (≈3 weeks), and the product itself needs **at least one successful sale**. So Discover — the compounding, no-audience distribution channel — cannot be the first channel. The first sale has to come from somewhere else. |
| Launch-price discount | ✅ `LAUNCH39` — $110 off all products (US$149 → US$39), link live at teeterbot.gumroad.com/l/claimgate/LAUNCH39, verified in a real browser (struck-through A$213.30 → A$55.83), created 2026-09-30. Still `0/∞ uses · No end date · Live` on 2026-09-30 (fourth tick) |
| Launch price on **every warm-buyer surface** | ✅ **added 2026-09-30 (fifth tick).** The launch price was on the landing page and the two listings, and **missing from every other surface a reader arrives from**: the free kit's README *and* CHECKLIST (both shipped inside the download), the public README, `docs/SUPPORT.md`, and the footer of `editorial-exemption.html`. All five fixed and confirmed live. The live free-kit listing description was the worst of them: it read "One-off US$149 at github.com/caseone115/claimgate" — the *list* price, and a pointer to the source repo, not to the shop — shown to the reader who had just decided the free kit was worth their time. Verified from outside: `LAUNCH39` ×3 in the served HTML, the old sentence 0 times |
| Free kit has a **builder that refuses to ship a stale price** | ✅ **added 2026-09-30 (fifth tick).** `scripts/build_kit_dist.py` builds the kit from `claimgate.kit`, reproducibly (two builds, identical SHA-256 `5cdb11be…`), then reads the README back **out of the finished zip** and refuses to build unless it carries the launch link, both prices, and no stale check count. The kit had *no* builder before this, which is exactly how its README drifted |
| Both live listings serve the rebuilt archives | ✅ **2026-09-30 (fifth tick).** Free kit: only the new 6.3 KB archive (the stale 6.1 KB one had to be deleted separately — uploading *adds* rather than replaces, so both were briefly attached). Paid: only the new 49.9 KB archive (stale 40.7 KB deleted). Both confirmed by reopening the editor against the server, not by trusting the save |
| Launch price visible **on the listing itself** | ✅ **added 2026-09-30.** The product description now opens with the launch price, the list price and the launch link. Verified on the live public listing (renders as the page's `og:description`). Before this, a visitor arriving from search or a share saw a listing that never mentioned $39 |
| Gumroad **auto-apply discount** toggle | ❌ **found and does not save.** The toggle exists (product editor → Pricing → `Automatically apply discount code`) — the 2026-09-30 third-tick note that Gumroad "has no automatically apply toggle" is **wrong**. It was switched on and saved 3×; it reverts to off every time and the public page does not change. Cause probed: its `Discount code` search widget returns **no `LAUNCH39` option**, so the code is typed but never selected, and there is nothing valid for the switch to save. The listing's headline price is therefore still US$149; the discount applies through the launch link or the code at checkout |
| Packaged as a sellable download | ✅ `dist/claimgate-0.1.0.zip` |
| Download verified **from inside the archive** | ✅ 112/112 pass in the extracted copy (55 engine + 36 kit + 21 outreach) |
| **Discount scope** | ✅ **fixed 2026-09-30 (sixth tick).** `LAUNCH39` was scoped to *all products* and was giving the second product away free: `teeterbot.gumroad.com/l/simscan/LAUNCH39` rendered **A$20.06 → A$0** in a logged-out browser. SimScan is now excluded. Verified after saving, from outside: SimScan with the code attached renders plain A$20.06 with no struck-through price, while ClaimGate with the same code still renders A$213.51 struck through to A$55.89 |
| **Discount code field at checkout** | ✅ **fixed 2026-09-30 (sixth tick).** `Checkout → Checkout form → Add discount code field` was set to **Never**, so the launch price was reachable only through the exact launch link and through no other route. Switched to *Only if a discount is available*, saved, and exercised as a stranger: cart A$216.31 → code applied → **A$61.90** (US$39 + GST) on a logged-out checkout |
| **A person is waiting for an answer** | ⚠️ **raised 2026-09-30 (sixth tick), not fixed.** The inbox watcher reports 1 person-mail awaiting an answer: the owner's own 2026-09-29 "ClaimGate trial" message. Deliberately not auto-answered — replying to the owner as if they were a prospect would be worse than silence. Re-raised every run until the owner closes it |
| Landing page + pricing | ✅ https://caseone115.github.io/claimgate/ |
| Source, MIT licensed | ✅ https://github.com/caseone115/claimgate |
| Gumroad seller account | ✅ `teeterbot` — email confirmed, payout rail connected |
| Product listing | ✅ description, US$149 one-off, slug `claimgate`, zip attached |
| **Product live for sale** | ✅ **published — https://teeterbot.gumroad.com/l/claimgate** |
| Payout rail | ✅ AU bank account, AUD, weekly, US$100 minimum |
| Outreach engine | ✅ built, guarded; **2 real recipients sent 2026-09-30**, 8 queued. Cap measured off the guard 2026-09-30 (seventh tick): 3/3 in window now; **one** slot opens 2026-09-30 02:00 UTC / 12:00 AEST (the self-test transport row drops out), the other two at 15:00 UTC / 2026-10-01 01:00 AEST. Hour-granular sample — treat as "first tick after" |
| **Citable artifact for outreach** | ✅ https://caseone115.github.io/claimgate/editorial-exemption.html — Article 50(4) editorial exemption, sourced from the Commission's own July 2026 guidance |
| **Standing shop probe** | ✅ **fixed 2026-09-30 (seventh tick).** It had been crying wolf: it asserted the discounted price as the exact cents seen on the day it was written (A$55.89 / A$55.83), so when FX moved the list price A$213.51 → A$213.81 the launch price read A$55.96 and a working 74% discount was reported as a regression. It now asserts the **ratio** (39/149), which is currency-blind, and was proved against the real page plus four deliberately broken cases it still catches |
| **Browser automation (was silently dead)** | ✅ **fixed 2026-09-30 (seventh tick).** Every browser run was dying with `Failed to create SingletonLock: File exists`. The cause was not the lock: **48 orphaned headless Chrome processes** from earlier runs were still alive on our two profile dirs and holding them — agent-browser leaves Chrome running on exit, so the run *after* any browser run failed. The shop was unreachable to every automated check while `daily_probe.sh` still printed `STATUS: ok`. `scripts/browser.py` now reaps our own orphans (matched by exact `--user-data-dir`; proved not to match a profile we do not own), clears stale locks, reaps once per process, and the probe cleans up after itself. Verified by two consecutive green runs — the thing that used to be impossible |
| **Traffic actually observed** | 📊 **39 views in the last 30 days, 0 sales**, read from inside the account 2026-09-30 (seventh tick) now that browsing works again. 3 views placed in the United States, the rest unplaced. Balance $0, last 7 days $0, last 28 days $0, total earnings $0 on all three listings; the dashboard's own "Make your first sale" step is unticked. This is a sample that says nobody has been given a reason to buy yet — not that the price is wrong |
| Inbox watcher | ✅ a human reply can no longer sit unread |
| Storefront art (cover + thumbnail) | ✅ both listings, verified live |
| Listing name | ✅ "ClaimGate — Publish Gate for AI-Assisted Marketing Copy" |
| Seller profile (name + bio) | ✅ was blank; now written and public |
| Affiliate scheme | ✅ 30% on the paid product; signup page live |
| Continuous autonomous operation | ✅ cron 298d128036cc, every 30 minutes |
| **A sale** | ❌ none yet |
| Two stale test-count claims | ✅ **fixed 2026-09-30 (fifth tick).** The kit README sold a "45-check test suite" (it is 55) and the public README quoted 45 for the engine. A claim-checking product quoting its own test count wrong is the exact failure it exists to catch |
| **A second product on sale** | ✅ SimScan US$14 - teeterbot.gumroad.com/l/simscan |
| SimScan's own page | ✅ https://caseone115.github.io/simscan/ |
| SimScan installer on sale = the CI-proven build | ✅ fixed 2026-09-29 (was serving an untested local build whose checksum its own SHA256SUMS.txt contradicted) |

- 2026-09-29 — **SimScan listing was selling the wrong installer; fixed.** The
  attached `Setup.exe` was an old local Wine build (`2ceab6b8…`) while the
  `SHA256SUMS.txt` attached beside it named the CI-proven build (`287f54be…`) —
  so the verification step the listing itself invites would fail. The CI build
  was downloaded, uploaded to the listing, hash-confirmed to match *before*
  anything was removed, the stale row deleted, saved, and then all three files
  were re-downloaded from the live listing and every hash matched. The local
  `release/` copies were replaced with the CI artifacts and the stale build kept
  as `SimScan-1.0.0-Setup.exe.stale-local-build`. A description sentence telling
  buyers the checksums are "published in the repository" was rewritten (the repo
  ships source and tests only, so they were tracked nowhere in git). SimScan's
  own page is live at caseone115.github.io/simscan/. Revenue: $0.00.
- 2026-09-29 — **Shop presentation fixed.** Neither listing had a cover image or
  a thumbnail, so every appearance — search, profile, a shared link — fell back
  to Gumroad's grey placeholder. Generated deterministic art in the landing
  page's palette (`scripts/make_storefront_art.py`), uploaded to both listings,
  verified live from outside. The paid listing was also named the lowercase slug
  `claimgate`; it now reads "ClaimGate — Publish Gate for AI-Assisted Marketing
  Copy" (confirmed in `og:title`). The seller profile had no name and no bio at
  all; both are now written and public.
- 2026-09-29 — **Affiliate scheme enabled at 30% on the paid product.** Verified
  from outside: `teeterbot.gumroad.com/affiliates` returned 404 beforehand and
  now serves "Become an affiliate for ClaimGate". Costs nothing unless a
  referred sale happens — the only channel that borrows an audience we do not
  have, and paid advertising produced 0 of 70 documented first sales.
- 2026-09-29 — **Free starter kit published as a second listing**
  (`teeterbot.gumroad.com/l/claimgate-starter-kit`) at US$0 with the contribution
  box enabled; verified from an unauthenticated fetch as `price: 0.0`. It exists
  to accumulate the ratings and sales history that gumroad Discover requires and
  that a $149 listing with no reviews cannot get. A buyer-view check corrected a
  wrong earlier assumption: the contribution box does appear on a $0 product.
  Revenue: $0.00.

- 2026-09-30 (fourth tick) — **The launch price is now on the product listing
  itself, and this ledger's own note about the auto-apply toggle was wrong.**
  Two things, one done and one not, both recorded rather than smoothed over.
  **(a) Done.** The listing description opened straight into the pitch with no
  price in it, so anyone arriving from search, a share or a bookmark saw a page
  that never mentioned US$39 — the previous tick had pointed the *landing page*
  at the launch link, but the *shop listing* is a different surface and said
  nothing. The description now begins: *"Launch price: US$39 while the launch is
  running, list price US$149. Buy through
  https://teeterbot.gumroad.com/l/claimgate/LAUNCH39 and the US$110 discount
  applies at checkout."* The old text was backed up to `state/_desc_backup.txt`
  (3979 chars) before editing, saved, and **verified on the live public listing
  from outside** — it renders as the page's `og:description`, with "Launch
  price", "LAUNCH39" and "US$39" each present nine times, and the listing is
  still `is_published: true` and still lists at US$149 from its own URL.
  **(b) Not done, and the correction matters more than the feature.** This
  ledger claimed on 2026-09-30 that Gumroad "has no 'automatically apply
  discount code' toggle". **That was false.** The toggle is right there in the
  product editor under Pricing. It was found, the `Discount code` box accepted
  `LAUNCH39`, the switch genuinely moved to on, and it was saved three times —
  **and it reverted to off every single time**, with the public page unchanged at
  A$213.30. Probing the cause: the code box is a search widget whose filtered
  option list contains **no `LAUNCH39` entry at all**, so the string is typed into
  the input but no real option is ever selected and the selection is never
  committed. That is a widget/options problem, not a missing feature — and the
  distinction is the whole point, because "Gumroad cannot do this" would have
  stopped anyone trying again. **The honest position on price reach:** the landing
  page and the listing description both state the launch price; the listing's own
  headline price remains US$149, and the discount is applied via the launch link
  or the code at checkout.
  Re-verified unchanged this tick: the suite at 55/55 + 34/34 + 21/21, the site
  and repo at HTTP 200, the mailbox quiet, and the discount still
  `$110 off of all products · 0/∞ uses · No end date · Live`.
  Revenue: $0.00. A discount is not a sale and is not counted as one.
- 2026-09-30 (fourth tick) — **The next three outreach messages could not be
  sent, and the portfolio's date for when they can be was wrong.** The guard
  returned `daily limit reached (3/3 in the last 24h)` and refused all three —
  correctly. The rolling 24h window runs from the actual send timestamps
  (2026-09-29 14:04 UTC in `state/outreach_sent.jsonl`), so the next three can go
  at the first tick after **2026-09-30 14:04 UTC / 2026-10-01 00:04 AEST**. Earlier
  prose in `PORTFOLIO.md` and `WORKLOG.md` said the window cleared at 00:04 AEST
  on 2026-09-30; it does not, and this run was still inside it. The timestamps in
  the log are the authority, not the prose. All three queued recipients (Solomon
  Advising, EMF Consultants, ZORC AB) were re-read page-by-page this tick and
  every address and quoted hook is still traceable, so nothing in the queue has
  gone stale while it waits. Nothing was sent, so nothing is claimed. Revenue:
  $0.00.

## The commercial facts, plainly

- Price: **US$149, one-off**. Gumroad's page shows buyers the approximate local
  currency; the seller is paid in AUD.
- Gumroad's fee on a direct sale: 10% + US$0.50 + 2.9% + US$0.30 card fee.
- Gumroad on a Discover sale: 30% flat.
- Payouts: weekly, once the balance passes US$100 — so the first ~$100 earned
  stays in the account until the threshold is crossed.
- Refunds: 30-day money-back guarantee, configured on the product.

## What is genuinely autonomous today

- The product exists, is tested, and is live and payable
- Marketing runs daily without input
- This revenue figure updates daily without input
- Nothing on the critical path needs a human any more

## The front door: the free starter kit

The product was finished and live but had nothing a stranger could try without
paying. `claimgate init` is that front door: a policy file, an evidence folder, a
draft template, a six-question pre-publish checklist (AI-disclosure section
included) and a GitHub Actions job that gates every pull request. No API key, no
network, genuinely free, and it stays free.

It is load-bearing rather than decorative — it is the thing that gets adopted,
the thing that produces the first real run against somebody's own copy, and the
only honest route from "never heard of this" to "this found something in my
draft".

## The risk, stated plainly

The engine is MIT-licensed and readable, so a determined buyer can self-assemble
it, and the free kit may cannibalise the paid download. The metric that settles
this is whether kit adoption produces replies and sales, not downloads.

## The honest position on demand

Validated, not assumed — but validation is not revenue:

- EU AI Act Article 50 transparency obligations in force 2 Aug 2026
- Gartner: AI governance platform spend $492M in 2026, $1B+ by 2030
- 76% of enterprises require human review before AI creative publishes
- 12,842 AI-written articles removed for hallucinated content in one quarter
- No incumbent found that substantiates an individual claim against supplied
  evidence; detectors answer a different question and governance suites report
  after the fact

That is evidence the problem is real and paid for. It is not evidence that
*this* product sells, and the difference matters.

## Log

- 2026-09-30 (seventh tick) — **The shop's own standing check was wrong in two
  ways, and the second was hiding a total outage of every browser-based check.**
  It started with running the queue's own probe instead of trusting it, and the
  probe failed (exit 1) claiming three doors were broken.
  **(a) It was crying wolf.** The probe asserted the launch price as the exact
  cents from the day it was written (`A$55.89` / `A$55.83`). Gumroad renders in
  the visitor's currency, so when the list price moved `A$213.51 → A$213.81` the
  launch price read `A$55.96` and a working 74% discount was reported as a
  regression — for a check whose whole job is to be believed. It now asserts the
  **ratio**, `39/149`, which is the real invariant and currency-blind. Proved
  both ways: it passes every real render, including today's, and still fails four
  deliberately broken ones — discount not applying, product gone free, wrong
  coupon, no struck price at all. A check that cannot fail is not a check.
  **(b) The real fault, and it was not the one being reported.** Every browser run
  was dying with `Failed to create SingletonLock: File exists` (Chrome exit 21).
  The cause was **not** a stale lock: **48 orphaned headless Chrome processes**
  were still alive on our two profile dirs and holding them. agent-browser leaves
  Chrome running when a script exits, so **the run after any browser run failed**.
  That means the shop had become unreachable to every automated check while
  `daily_probe.sh` went on reporting `STATUS: ok`, because it never starts a
  browser — a real outage invisible from every health surface we had.
  `scripts/browser.py` is now the single self-healing driver: reaps our own
  orphans (matched by the exact `--user-data-dir`, **proved not to match a profile
  we do not own**), clears stale locks, reaps **once per process**, and the probe
  cleans up after itself so they cannot re-accumulate. Two mistakes of mine were
  caught by running it rather than reasoning about it: reaping on *every* call
  killed the browser between `open` and `eval` and produced three *false* breaks
  on a shop that was fine, and the helper was first written into gitignored
  `state/`, where the tracked probe importing it would break on a fresh clone.
  **Verified: two consecutive green runs** (`0` Chrome left running afterwards),
  `daily_probe.sh` still `55/55 + 36/36 + 21/21`, site 200, repo 200.
  **(c) With browsing repaired, the real numbers were read from inside the
  account** instead of guessed: **39 views, 0 sales** on all three listings;
  Balance $0, last 7 days $0, last 28 days $0, total earnings $0; 3 views from the
  United States, the rest unplaced; the dashboard's own "Make your first sale"
  step unticked. The inbox is quiet — the only person-mail on record is still the
  owner's own 2026-09-29 trial message, deliberately not auto-answered.
  **Revenue: $0.00 — a fixed check is not a sale, and 39 views is not demand.**
  No sale, no reply, no traffic change attributed to anything.

- 2026-09-30 — **The first citable piece was published, and running the tool over
  it produced a real bug fix.** The article at
  https://caseone115.github.io/claimgate/editorial-exemption.html sets out what the
  Article 50(4) human-review exemption actually requires before AI-assisted published
  text escapes the labelling duty. It is built from the Commission's own July 2026 FAQ
  and guidelines rather than from commentary, with every source linked, and it makes
  two points that are hard to find stated together: that the exemption is *cumulative*
  (a process and a named responsible person, not either), and that the Commission's
  guidance requires the responsible person's **identity and contact details to be
  publicly available** — which almost no published AI policy contains. It is honest
  about its own limit: the §138 paragraph reference rests on a law firm's reading
  because the guidelines PDF could not be fetched from this machine, and the page says
  so in the body rather than in a footnote.
  The piece was then run through ClaimGate itself against an evidence file of its own
  citations. **The first run blocked it**: fifteen claim findings and one blocking
  policy finding. The policy finding was a genuine defect in the tool — the `no-medical`
  prohibited rule matched the bare English verb `treats?` with no requirement that a
  medical outcome appear near it, so "Treat the paragraph number as second-hand" raised
  a *blocking* finding. A blocking false positive is the worst defect a gate can have,
  because it teaches the operator to ignore the gate. Fixed: the rule now requires an
  outcome from a fixed list in the same sentence as the verb; ten regression checks
  added (five that plain English no longer trips it, five that real medical claims still
  do); suite 45 → **55/55**, probe confirms. The other fifteen findings were genuine and
  were on the writing, not the tool: sweeping assertions about practice ("missing from
  almost every AI policy", "almost never dishonesty") that no cited source supports and
  which the page had no way to know. Rewritten to say what the sources establish; final
  run clean. **The page now describes this honestly, including that it was blocked, and
  was itself subject to this check a second time** — the sentences *about* the bug had
  to be evidenced too. Revenue: $0.00 — an article is not revenue and is not counted as
  any.
- 2026-09-30 — **The first two real messages to real people went out, and the
  target list was built out of the recipients' own published words.** Not a
  mailing list and not scraped addresses: each recipient is a company that has
  publicly committed in writing to reviewing AI-assisted content, and each
  address was read off the page carrying the sentence being quoted.
  `info@frankcaremarketing.com` (Frank Care Marketing, UK care-sector
  marketing) publishes a log of "the prompt used, the output generated, the
  reviewer notes and human oversight steps" — a genuinely strong documentation
  position, but the log shows a human read the draft and says nothing about
  whether the claims in it were substantiated. `hello@katiefarrell-econsultant.com`
  (Katie Farrell E-Consultant, UK; Klaviyo and email for ecommerce) promises
  human review before publication and hedges disclosure as "when appropriate",
  which is the discretionary wording Art.50 does not offer. Each message names
  the gap between the promise and what a documented editorial-control defence
  requires, and offers a free run over a draft the recipient has already
  published — no signup, no call, no sequence. Both say in the first line that
  they were written by automated software and that there will not be a second
  message. Enforced by code, not memory: three a day, one per company, never the
  same address twice, hook required to appear in the body (`state/outreach_sent.jsonl`
  is the permanent record; `state/outreach_targets.md` is the queue).
  Seven further recipients are researched and verified for the following ticks.
  Two candidates were **excluded, not skipped**: PerformLine and Bill Rice
  Strategy Group publish on exactly this problem, but each is a vendor in the
  space, and being a competitor is not a hook.
  **Nothing came back** — the mailbox was checked twice and is quiet. 8 of the 10
  messages remain queued because the daily limit, not the writing, is the
  constraint. Revenue: $0.00.
- 2026-09-29 - **Two products now on sale, and the money checked from inside the
  account.** Signed in to Gumroad and read the real figures rather than inferring
  them: dashboard Balance $0 USD, Last 7 days $0, Last 28 days $0, Total earnings
  $0; the products table shows 0 sales and $0 revenue on both listings; 0 customers
  on each. SimScan was listed as a second, unrelated product at US$14 (id `ghnmdw`,
  slug `simscan`), which tests the rail and the shop independently of ClaimGate.
  A listing claim was corrected to be exactly true - an earlier draft read as
  though SHA-256 checksums and the test suite shipped inside the download; they are
  published in the public repo instead, and the sentence now says that. Revenue:
  $0.00 - still the only thing missing is a customer.



- 2026-09-29 — **Free starter kit built and shipped** (`claimgate init`): policy
  file + notes, evidence folder, draft template, six-question checklist, CI job —
  34 tests. The download is now built by `scripts/build_dist.py`, which refuses
  to ship unless all 79 checks pass *from inside the extracted archive* and the
  archive carries no credential or contact list. Landing page pricing rewritten
  around the free kit and the paid engine, CTAs repointed, `docs/SUPPORT.md`
  added for the questions a buyer actually asks (is there a human; GDPR; who is
  responsible). Inbox watcher built and run against the live mailbox — it found
  one real message: the owner's own trial email, which proved the site's trial
  CTA works and that its prefilled body arrives empty. Fixed: the CTA now asks
  for the draft as the body. Revenue: $0.00.
- 2026-09-29 — **Payout rail connected by the owner: AU bank account, AUD,
  weekly schedule, US$100 minimum.** Product published and live at
  https://teeterbot.gumroad.com/l/claimgate. Listing brought up to standard:
  full description written, price converted from A$149 to a one-off US$149,
  clean URL slug `claimgate` set (product id remains `nlzlj`), download and
  30-day refund policy attached. Landing page pricing rewritten to match the
  real product — the old page advertised Team/Regulated monthly tiers that do
  not exist, which was a claim we could not substantiate, and the "buy" path
  now goes to a real checkout. Revenue: $0.00.
- 2026-09-29 — ClaimGate 0.1.0 built, tested (45/45 engine + 21/21 outreach),
  published under MIT, landing page live. Gumroad account created and email
  confirmed; product listing completed with description, A$149 price, slug
  `claimgate` and the zip attached. Publish was then blocked on the payout
  method. Outreach transport proven with a real send. Revenue: $0.00.
- 2026-09-29 — Revenue $0.00.

- 2026-09-30 (third tick) — **The first price cut is live, and turning it on found a
  wrong assumption in this ledger.** Gumroad's own help centre was read rather than
  guessed at, and Discover turns out to be gated behind a completed sale: eligibility
  needs a $100 balance from *genuine sales* and a risk-review pass, and the product
  itself needs at least one successful sale before it is listed. That retires the
  reasoning recorded on 2026-09-29 that the free starter kit exists to "accumulate the
  ratings and sales history that Gumroad Discover requires" — a free listing with no
  sale cannot reach Discover at all, so the free kit is a *conversion* instrument, not
  a Discover instrument. The first sale therefore has to come from outreach and from
  the free kit, and price has to stop being the thing standing in the way.
  So a discount was created and is live: **`LAUNCH39`, $110 off all products**,
  which takes the $149 listing to **US$39** — inside the $19–55 band that every
  comparable in this niche sits in. The auto-apply link is
  https://teeterbot.gumroad.com/l/claimgate/LAUNCH39 and was verified by opening it
  in a real browser: the page now shows the old price struck through and the new one
  beside it (A$213.30 → A$55.83 in the seller's own currency display). Gumroad has no
  "automatically apply" toggle the way the work item assumed; its own mechanism is a
  per-product link with the code appended, which is what the landing page will point
  at. Recorded plainly: **the $149 list price was left untouched**, so this is a
  reversible experiment and not a price change. It is currently open-ended, and the
  21-day clock starts now — reverting or re-cutting at the end of it.
  **Two errors of mine were caught and fixed while doing this**, both worth recording
  because both would have been silent: a first edit saved the discount with an
  end date of *tonight*, which would have ended the experiment in an hour without
  anyone noticing; and an earlier attempt at the same edit produced a blank end date.
  Both were caught by reading the discount back off the page after saving rather than
  trusting the save. Final state verified on the list: `LAUNCH39 · $110 off of all
  products · 0/∞ uses · No end date · Live`.
  Revenue: $0.00. A discount is not a sale and is not counted as one.
- 2026-09-30 (third tick) — **The outreach queue was completed to the ten the task
  asks for, and one candidate was held back rather than padded in.** Two more
  recipients were verified to the same standard as the rest — the hook quoted
  verbatim, the address read off the page carrying it — bringing eight verified
  names against the ten-message task. The strongest new one is **Gecko Studio**
  (Ibiza, Spain; trading as Digitec Ibiza Informatica, S.L.): an EU deployer that
  cites Article 50 by number, has already published the name of the person holding
  editorial responsibility — which is exactly the requirement almost nobody meets —
  and states "We do not publish unverified data. Figures, names, prices and claims
  about clients are checked against their source before publication", while naming
  nothing that shows the check happened. That is the gap the product fills, stated
  in the recipient's own words.
  **One candidate was deliberately HELD rather than queued**: devEdge Internet
  Marketing (Victoria BC) publishes a review commitment worth writing to, but its
  address has not been read off a page, and it is Canadian rather than EU — so the
  Art.50 framing every other message uses would have to be rewritten for it. Padding
  the queue to exactly ten with a name that is neither verified nor suited would have
  made the number look better and the work worse.
  **Seven further candidates were excluded on principle**, all recorded in
  `state/outreach_targets.md` so no later tick re-does the search or "fixes" the
  decision: The Content Lab, Zoopa, AI-Ready CMO, Blanche AI Compliance, VerifAI,
  Like a Human AI and AutomateIQ all publish on precisely this problem — and all of
  them sell the advice, the training or the competing tool. Being a rival is not a
  hook. Revenue: $0.00.
- 2026-09-30 (third tick) — **The launch price is now reachable by anyone, not just
  by whoever already had the link.** A discount that exists only on a URL nobody
  visits is not an experiment, it is a note to self. The public landing page
  (https://caseone115.github.io/claimgate/) sent every buyer to the $149 checkout and
  mentioned the launch price nowhere, so all five buy links were repointed at
  `teeterbot.gumroad.com/l/claimgate/LAUNCH39`, and the pricing card now shows the
  list price struck through beside the launch price: **$149 → $39, one-off**. The
  card states plainly that $39 applies while the launch is running and that $149 is
  the list price it returns to, so the offer is honest about being temporary rather
  than pretending $39 is the price. Pushed (`77c4b6f`) and verified **on the live
  Pages site** (HTTP 200, five launch links present, `<s>$149</s> $39` in the pricing
  card) rather than on the built output. Revenue: $0.00.

- 2026-09-30 (fifth tick) — **Every warm-buyer surface was still quoting the
  $149 list price; all of them now carry the launch price.** The audit that
  caught it went over the surfaces the previous tick did not check, and found
  the price cut had never reached the people most likely to act on it. Five
  surfaces fixed (kit README, kit CHECKLIST, public README, `docs/SUPPORT.md`,
  the outreach article footer), plus the live free-kit listing description,
  which had named the list price and sent readers to the source repo instead of
  the shop. The cause was structural — the kit was hand-built with no builder to
  catch drift — so it was fixed structurally: `scripts/build_kit_dist.py` now
  builds the kit reproducibly and reads its own README back out of the finished
  zip, refusing to ship unless it carries the launch link and both prices; the
  kit test suite got the same contract (34 → 36). Both archives rebuilt and
  verified from inside the extracted copy (112/112), both live listings now
  serve the rebuilt files, pushed `442fbed`. Also corrected: this file's and
  `WORKLOG.md`'s claim that the outreach cap clears at 00:04 AEST tomorrow was
  pessimistic by ten hours — the guard was driven directly at future times
  (`state/cap_when.py`) and one message clears at 2026-09-30 01:44 UTC, when the
  self-test transport row (not a prospect) falls out of the 24h window.
  **Revenue: $0.00 — a corrected price is not a sale.**

- 2026-09-30 (sixth tick) — **Two ways the shop was losing money, found by
  shopping in it logged-out as a stranger, and both fixed and verified.** Every
  previous tick audited the pages *we* publish, with our own session. This tick
  walked the buyer's path instead — no login, add to cart, checkout, pay — and
  found two defects that no page we control would ever have shown.
  **(a) The launch discount was giving a paid product away.** `LAUNCH39` is $110
  off **all products**; appended to the second product's link
  (`teeterbot.gumroad.com/l/simscan/LAUNCH39`) its page rendered **A$20.06 →
  A$0** in a logged-out browser, and the discounts list displayed the giveaway in
  plain text. A $110-off coupon on a A$20.06 product was never the intent — it
  exists to take a US$149 product to US$39. SimScan is now excluded from it.
  Verified after saving, from outside: SimScan with the code attached renders
  plain **A$20.06**, no struck-through price; ClaimGate with the same code still
  renders **A$213.51 struck through to A$55.89**.
  **(b) The checkout had no discount-code field.** `Checkout → Checkout form →
  Add discount code field to purchase form` was set to **Never**, so the launch
  price was usable only by someone arriving through the exact launch link — the
  same class of mistake as a discount on a URL nobody visits, in a different
  place. Switched to *Only if a discount is available*, saved, re-read after a
  reload to confirm it persisted, and then **exercised as a stranger**: cart
  A$216.31, `LAUNCH39` typed into the new field, Apply → **A$61.90**, which is
  the US$39 launch price plus Australian GST, on a logged-out checkout.
  **Also re-verified, unchanged:** the published landing page leads with
  A$213.51 and points at the launch link; suites 55/55 + 36/36 + 21/21; site
  200; repo 200; `LAUNCH39 · $110 off of all products except SimScan … · 0/∞ ·
  No end date · Live`.
  **Raised, not fixed:** the watcher reports **1 person-mail awaiting an
  answer** — the owner's own 2026-09-29 "ClaimGate trial" message. It is not a
  prospect's reply, and replying to the owner as though it were would be worse
  than the silence, so it is surfaced rather than auto-answered.
  **Revenue: $0.00 — closing a leak is not a sale.** No sale, no reply, no
  traffic change, nothing measured.
